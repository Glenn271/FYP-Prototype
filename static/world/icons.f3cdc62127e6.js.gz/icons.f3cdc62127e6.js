    var leafIcon = L.Icon.extend({
        options:{
            iconSize: [30, 30]
        }
    });

    var dinIcon = new leafIcon({iconUrl:'/static/images/utensils.svg'})

    var edIcon = new leafIcon({iconUrl:'/static/images/school.svg'})

    var entIcon = new leafIcon({iconUrl:'/static/images/theater-masks.svg'})

    var finIcon = new leafIcon({iconUrl:'/static/images/euro.svg'})

    var medIcon = new leafIcon({iconUrl:'/static/images/medkit.svg'})

    var transIcon = new leafIcon({iconUrl:'/static/images/subway.svg'})

    var houseIcon = new leafIcon({iconUrl:'/static/images/home.svg'})

    var shopIcon = new leafIcon({iconUrl:'/static/images/shopping-cart.svg'})